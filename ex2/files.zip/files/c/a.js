var $svg = $('svg').drawsvg();

$svg.drawsvg('animate');